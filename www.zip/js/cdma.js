function exitFromApp()
 {
 navigator.app.exitApp();
 }
function getLoading(){
	$("#myModal").reveal({               // The item which will be opened with reveal
        animation: 'fade',              // fade, fadeAndPop, none
         animationspeed: 100,            // how fast animtions are
         closeonbackgroundclick: true,   // if you click background will modal close?
         //display: 'block',
        dismissmodalclass: 'close-reveal-modal' //the class of a button or element that will close an open modal
    });
}

function getPropertyPage() {
	getLoading();
	window.location.replace('propertyTax.html');
}
function backPage() {
	
	window.location.replace('index.html');
}


function knowYourPropertyTax(){
	
	var  isSubmit=true;
	var assessmentNoId=document.getElementById('assessmentNoId').value;
	if(assessmentNoId ==''){
		alert('Please Enter assesment Number');
		isSubmit=false;
	}
	else if(isNaN(assessmentNoId)){
		alert('please enter Numbers only');
		isSubmit=false;
	}
	else if(assessmentNoId.length != 10){
		alert('Assesment Number should be in 10 digit');
		isSubmit=false;
	}
	
	
	
	if(isSubmit)
	{	
		getLoading();
		document.getElementById('assessmentNo').innerHtml=assessmentNoId;
		
	$.ajax({
	    type: 'GET',
	    url: 'http://125.16.9.166:8080/CDMA_TS_Dashboard/ws/knowYourTax/'+assessmentNoId,
	    dataType: 'xml',
	    success: function (response) {
	        $('DuesModel', response).each(function() {
	            
	            var responseMessage = $(this).find('responseMessage').text();
	           
	            if(responseMessage=='Success'){
	            	$('#assessmentNo').html($(this).find('assessmentNo').text());
	            	$('#locality').html($(this).find('locality').text());
	            	$('#vc_ONRNAME').html($(this).find('vc_ONRNAME').text());
	            	$('#vc_ONRSURNAME').html($(this).find('vc_ONRSURNAME').text());
	            	$('#vc_ONRADDR1').html($(this).find('vc_ONRADDR1').text());
	            	$('#vc_ONRDOORNO').html($(this).find('vc_ONRDOORNO').text());
	            	$('#ulbName').html($(this).find('ulbName').text());
	            	$('#districtName').html($(this).find('districtName').text());
	            	var cumulative=$(this).find('cumulative').text();
	            	var tableData = '';
	            	
	            
	            	 $('arrearDtls', response).each(function() {
	            		 var taxtype=$(this).find('taxTYPE').text();
	            		 var dmdYear=$(this).find('vc_DMNDYEAR').text();
	            		 var taxAmount =$(this).find('tax').text();
	            		 var penalty=$(this).find('penalty').text();
	            		 var total=$(this).find('total').text();
	            		 var cumtotal=parseFloat(cumulative).toFixed(2);
	            		 
	     	           tableData += '<tr ><td width="15%" >'+taxtype + '</td><td width="17%" >'+ dmdYear+ '</td><td width="16%" >'+ taxAmount+ '</td><td width="16%">'	+penalty+ '</td><td width="18%">'
						+ total
						+ '</td><td width="14%">'
						+ cumtotal+ '</td></tr>';
	     	           cumtotal=parseFloat(cumulative)-parseFloat(taxAmount);
	            		 cumulative=cumtotal;
	     	          
	     	        });
	            	
	            		$('#openOrdersList').html(tableData);
	            		document.getElementById("login_form").style.display = "none";
	            		document.getElementById("taxDetails").style.display = "block";
	            		$('#myModal,.reveal-modal-bg').css('display','none');
	            }else{
	            	
	            	alert('Else-------'+responseMessage);
	            	document.getElementById("login_form").style.display = "block";
	            	$('#myModal,.reveal-modal-bg').css('display','none');
	            }
	            
	        });
	    },
	    error: function (error) {
	        console.log(error);
	    }
	});
	
}
}